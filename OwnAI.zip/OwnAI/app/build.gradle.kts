plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.ownai.chat"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.ownai.chat"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        // Модель работает только на 64-битных телефонах (почти все современные)
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    // Офлайн-движок для запуска LLM на телефоне (без интернета и без ключей)
    implementation("com.google.mediapipe:tasks-genai:0.10.35")
}
