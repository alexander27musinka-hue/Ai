package com.ownai.chat

import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Скачивание большого файла с докачкой (если связь оборвалась). */
object Downloader {

    fun download(urlStr: String, dest: File, onProgress: (done: Long, total: Long) -> Unit) {
        val part = File(dest.parentFile, dest.name + ".part")
        var resumeFrom = if (part.exists()) part.length() else 0L

        var url = URL(urlStr)
        var conn: HttpURLConnection
        var redirects = 0
        while (true) {
            conn = url.openConnection() as HttpURLConnection
            conn.instanceFollowRedirects = false
            conn.connectTimeout = 20000
            conn.readTimeout = 30000
            conn.setRequestProperty("User-Agent", "OwnAI/1.0")
            if (resumeFrom > 0) conn.setRequestProperty("Range", "bytes=$resumeFrom-")
            val code = conn.responseCode
            if (code in 300..399) {
                val loc = conn.getHeaderField("Location") ?: throw IOException("Redirect без Location")
                url = URL(url, loc)
                conn.disconnect()
                if (++redirects > 8) throw IOException("Слишком много перенаправлений")
                continue
            }
            if (code == 416) { // файл уже докачан/диапазон неверный — начинаем заново
                conn.disconnect()
                part.delete()
                resumeFrom = 0
                continue
            }
            if (code != 200 && code != 206) throw IOException("HTTP $code")
            if (code == 200 && resumeFrom > 0) { // сервер не умеет докачку
                part.delete()
                resumeFrom = 0
            }
            break
        }

        val remaining = conn.contentLengthLong
        val total = if (remaining > 0) remaining + resumeFrom else -1L
        var done = resumeFrom
        var lastReport = 0L

        conn.inputStream.use { input ->
            FileOutputStream(part, resumeFrom > 0).use { out ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    done += n
                    val now = System.currentTimeMillis()
                    if (now - lastReport > 300) {
                        lastReport = now
                        onProgress(done, total)
                    }
                }
            }
        }
        conn.disconnect()
        if (total > 0 && done < total) throw IOException("Загрузка оборвалась")
        if (dest.exists()) dest.delete()
        if (!part.renameTo(dest)) throw IOException("Не удалось сохранить файл модели")
        onProgress(done, total)
    }
}
