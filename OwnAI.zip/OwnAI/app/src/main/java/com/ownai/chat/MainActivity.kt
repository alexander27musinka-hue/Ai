package com.ownai.chat

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors

class MainActivity : Activity() {

    companion object {
        // Бесплатная открытая модель Qwen2.5-0.5B-Instruct (Apache-2.0), ~550 МБ, ключ не нужен
        const val MODEL_URL =
            "https://huggingface.co/litert-community/Qwen2.5-0.5B-Instruct/resolve/main/" +
                "Qwen2.5-0.5B-Instruct_multi-prefill-seq_q8_ekv1280.task"

        const val SYSTEM_PROMPT =
            "Ты — дружелюбный ИИ-помощник внутри приложения «Свой ИИ». " +
                "Отвечай на языке собеседника, коротко и по делу."

        const val REQ_PICK = 42
    }

    private val ui = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var engine: LlmEngine? = null
    private val history = mutableListOf<Pair<String, String>>()
    private var generating = false

    private lateinit var chat: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var sendBtn: Button
    private lateinit var setupBox: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var progress: ProgressBar
    private lateinit var downloadBtn: Button
    private lateinit var pickBtn: Button

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun modelFile(): File {
        val dir = File(filesDir, "models")
        dir.mkdirs()
        return File(dir, "model.task")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (modelFile().exists()) {
            loadModel()
        } else {
            showSetup("Модель ещё не установлена. Нужно один раз скачать файл (~550 МБ, лучше по Wi-Fi). " +
                "После этого ИИ работает полностью офлайн.")
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0F1115.toInt())
            setPadding(dp(12), dp(12), dp(12), dp(12))
            fitsSystemWindows = true
        }

        // Шапка
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply {
            text = "Свой ИИ"
            setTextColor(Color.WHITE)
            textSize = 20f
        }
        header.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val newChat = Button(this).apply { text = "Новый чат"; setOnClickListener { resetChat() } }
        val modelBtn = Button(this).apply {
            text = "Модель"
            setOnClickListener {
                showSetup("Здесь можно скачать модель заново или выбрать свой файл .task.")
            }
        }
        header.addView(newChat)
        header.addView(modelBtn)
        root.addView(header)

        // Блок установки модели
        setupBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            visibility = View.GONE
        }
        statusText = TextView(this).apply { setTextColor(0xFFCBD5E1.toInt()); textSize = 14f }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            visibility = View.GONE
        }
        downloadBtn = Button(this).apply { text = "Скачать модель"; setOnClickListener { startDownload() } }
        pickBtn = Button(this).apply { text = "Выбрать файл .task"; setOnClickListener { pickFile() } }
        setupBox.addView(statusText)
        setupBox.addView(progress)
        setupBox.addView(downloadBtn)
        setupBox.addView(pickBtn)
        root.addView(setupBox)

        // Сообщения
        chat = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll = ScrollView(this).apply { addView(chat) }
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // Ввод
        val inputRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        input = EditText(this).apply {
            hint = "Напиши сообщение…"
            setHintTextColor(0xFF64748B.toInt())
            setTextColor(Color.WHITE)
            maxLines = 4
            imeOptions = EditorInfo.IME_ACTION_SEND
        }
        sendBtn = Button(this).apply {
            text = "➤"
            isEnabled = false
            setOnClickListener { send() }
        }
        inputRow.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        inputRow.addView(sendBtn)
        root.addView(inputRow)

        setContentView(root)
    }

    private fun addBubble(user: Boolean, message: String): TextView {
        val tv = TextView(this).apply {
            text = message
            setTextColor(Color.WHITE)
            textSize = 16f
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setTextIsSelectable(true)
            maxWidth = (resources.displayMetrics.widthPixels * 0.85).toInt()
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(if (user) 0xFF2563EB.toInt() else 0xFF1E2530.toInt())
            }
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.gravity = if (user) Gravity.END else Gravity.START
        lp.setMargins(0, dp(4), 0, dp(4))
        chat.addView(tv, lp)
        scrollDown()
        return tv
    }

    private fun scrollDown() {
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun resetChat() {
        history.clear()
        chat.removeAllViews()
    }

    private fun showSetup(message: String) {
        setupBox.visibility = View.VISIBLE
        statusText.text = message
        progress.visibility = View.GONE
        downloadBtn.isEnabled = true
        pickBtn.isEnabled = true
    }

    private fun setBusy(message: String) {
        setupBox.visibility = View.VISIBLE
        statusText.text = message
        progress.visibility = View.VISIBLE
        progress.isIndeterminate = true
        downloadBtn.isEnabled = false
        pickBtn.isEnabled = false
        sendBtn.isEnabled = false
    }

    private fun loadModel() {
        setBusy("Загружаю модель в память…")
        worker.execute {
            try {
                engine?.close()
                engine = null
                engine = LlmEngine(applicationContext, modelFile().absolutePath)
                ui.post {
                    setupBox.visibility = View.GONE
                    sendBtn.isEnabled = !generating
                    if (chat.childCount == 0) {
                        addBubble(false, "Привет! Я работаю прямо на твоём телефоне, без интернета и без ключей. О чём поговорим?")
                    }
                }
            } catch (t: Throwable) {
                ui.post {
                    showSetup("Не удалось запустить модель: ${t.message}\n" +
                        "Попробуй скачать заново или выбрать другой файл. Нужно ≥ 3 ГБ свободной RAM.")
                }
            }
        }
    }

    private fun startDownload() {
        downloadBtn.isEnabled = false
        pickBtn.isEnabled = false
        progress.visibility = View.VISIBLE
        progress.isIndeterminate = false
        progress.progress = 0
        statusText.text = "Подключаюсь…"
        worker.execute {
            try {
                Downloader.download(MODEL_URL, modelFile()) { done, total ->
                    ui.post {
                        if (total > 0) {
                            progress.progress = (done * 1000 / total).toInt()
                            statusText.text = "Скачивание: ${done / 1048576} / ${total / 1048576} МБ"
                        } else {
                            statusText.text = "Скачано ${done / 1048576} МБ"
                        }
                    }
                }
                ui.post { loadModel() }
            } catch (t: Throwable) {
                ui.post {
                    showSetup("Ошибка загрузки: ${t.message}\nНажми «Скачать модель» ещё раз — докачается с места остановки.")
                }
            }
        }
    }

    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(i, REQ_PICK)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PICK || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        setBusy("Копирую файл модели…")
        worker.execute {
            try {
                val stream = contentResolver.openInputStream(uri) ?: throw IllegalStateException("не удалось открыть файл")
                stream.use { inp ->
                    FileOutputStream(modelFile()).use { out -> inp.copyTo(out, 65536) }
                }
                ui.post { loadModel() }
            } catch (t: Throwable) {
                ui.post { showSetup("Ошибка копирования: ${t.message}") }
            }
        }
    }

    private fun send() {
        val text = input.text.toString().trim()
        val eng = engine
        if (text.isEmpty() || eng == null || generating) return
        input.setText("")
        generating = true
        sendBtn.isEnabled = false

        addBubble(true, text)
        history.add("user" to text.take(1200))
        val bubble = addBubble(false, "…")
        val snapshot = history.toList()

        worker.execute {
            var ok = true
            val answer = try {
                val raw = eng.generate(LlmEngine.buildPrompt(SYSTEM_PROMPT, snapshot))
                LlmEngine.clean(raw).ifEmpty { "(пустой ответ, попробуй переформулировать)" }
            } catch (t: Throwable) {
                ok = false
                "Ошибка: ${t.message}"
            }
            ui.post {
                bubble.text = answer
                if (ok) history.add("assistant" to answer) else history.clear()
                generating = false
                sendBtn.isEnabled = engine != null
                scrollDown()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        engine?.close()
        engine = null
    }
}
