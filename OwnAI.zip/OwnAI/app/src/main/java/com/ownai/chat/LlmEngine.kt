package com.ownai.chat

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference

/**
 * Обёртка над локальной моделью. Всё считается на телефоне, без сети и без API-ключей.
 * Модель по умолчанию: Qwen2.5-0.5B-Instruct (Apache-2.0).
 */
class LlmEngine(context: Context, modelPath: String) {

    private val llm: LlmInference

    init {
        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(modelPath)
            .setMaxTokens(MAX_TOKENS) // сумма: вопрос + история + ответ
            .build()
        llm = LlmInference.createFromOptions(context, options)
    }

    fun generate(prompt: String): String = llm.generateResponse(prompt)

    fun close() {
        try { llm.close() } catch (_: Throwable) {}
    }

    companion object {
        const val MAX_TOKENS = 1280
        private const val PROMPT_CHAR_BUDGET = 1500

        /** Формат диалога ChatML — его понимает Qwen. */
        fun buildPrompt(system: String, history: List<Pair<String, String>>): String {
            val parts = ArrayList<String>()
            var budget = PROMPT_CHAR_BUDGET
            for (i in history.indices.reversed()) {
                val (role, text) = history[i]
                val piece = "<|im_start|>$role\n$text<|im_end|>\n"
                if (piece.length > budget && parts.isNotEmpty()) break
                parts.add(0, piece)
                budget -= piece.length
            }
            return "<|im_start|>system\n$system<|im_end|>\n" +
                parts.joinToString("") +
                "<|im_start|>assistant\n"
        }

        fun clean(raw: String): String =
            raw.substringBefore("<|im_start|>")
                .replace("<|im_end|>", "")
                .replace("<|endoftext|>", "")
                .trim()
    }
}
