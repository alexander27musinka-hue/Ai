# Свой ИИ (офлайн-чат на телефоне)

Приложение запускает открытую модель Qwen2.5-0.5B-Instruct прямо на телефоне.
Без API-ключей, без аккаунтов, без сервера. Интернет нужен один раз — скачать модель (~550 МБ).

- Движок: MediaPipe LLM Inference (com.google.mediapipe:tasks-genai)
- Модель: litert-community/Qwen2.5-0.5B-Instruct (Apache-2.0)
- Свой файл модели: кнопка «Выбрать файл .task» (формат MediaPipe .task)
- Замена модели по умолчанию: константа MODEL_URL в MainActivity.kt
- Системная «личность» бота: константа SYSTEM_PROMPT в MainActivity.kt
